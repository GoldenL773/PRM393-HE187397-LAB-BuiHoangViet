import 'package:flutter/material.dart';
import 'location.dart';

class LocationDetail extends StatelessWidget {
  final Location location;

  const LocationDetail({super.key, required this.location});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter layout demo'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network(
              'https://fastly.picsum.photos/id/935/600/240.jpg?hmac=OJj8XI8MSDNlRbYwsO96lL82Avc_ReDpGczEe5GC_-o',
              width: double.infinity,
              height: 240,
              fit: BoxFit.cover
            ),
            _buildTitleSection(),
            _buildButtonSection(context),
            _buildTextSection(),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SecondPage()),
                );
              },
              child: const Text('Go to Another Page'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTitleSection() {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    location.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  location.address,
                  style: TextStyle(
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.star,
            color: const Color.fromARGB(255, 244, 241, 54),
          ),
          const SizedBox(width: 4),
          Text('${location.count}'),
        ],
      ),
    );
  }

  Widget _buildButtonSection(BuildContext context) {
    Color color = Theme.of(context).primaryColor;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildButtonColumn(color, Icons.call, 'CALL'),
        _buildButtonColumn(color, Icons.near_me, 'ROUTE'),
        _buildButtonColumn(color, Icons.share, 'SHARE'),
      ],
    );
  }

  Column _buildButtonColumn(Color color, IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color),
        Container(
          margin: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTextSection() {
    return const Padding(
      padding: EdgeInsets.all(32),
      child: Text(
        """Định nghĩa class location gồm các thông tin id, name, address, count, star.
Thiết kế giao diện cho trang detail location hiển thị thông tin như ảnh; sinh viên có thể thiết kế thêm appbar, button navigation để điều hướng sang 1 trang khác và điều hướng ngược lại """
        ,
        softWrap: true,
      ),
    );
  }
}

class SecondPage extends StatelessWidget {
  const SecondPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Second Page'),
      ),
      body: Center(
        child: Column(
          children: [
            Text('Nothing'),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child:
              const Text('Go back!'),
            ),
            ],
        ),
        
      ),
    );
  }
}

