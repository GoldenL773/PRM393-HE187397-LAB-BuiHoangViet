class Location {
  final String id;
  final String name;
  final String address;
  final int count;
  final double star;

  Location({
    required this.id,
    required this.name,
    required this.address,
    required this.count,
    required this.star,
  });
}

