import 'package:flutter/material.dart';
import 'location.dart';
import 'location_detail.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Layout Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: LocationDetail(
        location: Location(
          id: '1',
          name: 'Oeschinen Lake Campground',
          address: 'Kandersteg, Switzerland',
          count: 41,
          star: 4.5,
        ),
      ),
    );
  }
}
